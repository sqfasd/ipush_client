//
//  XClientOption.m
//  xcomet
//
//  Created by kimziv on 15/5/7.
//  Copyright (c) 2015年 kimziv. All rights reserved.
//

#import "XClientOption.h"

@implementation XClientOption
@synthesize host=_host;
@synthesize port=_port;
@synthesize userName=_userName;
@synthesize password=_password;

@end
