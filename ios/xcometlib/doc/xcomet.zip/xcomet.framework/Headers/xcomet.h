//
//  xcomet.h
//  xcomet
//
//  Created by kimziv on 15/5/11.
//  Copyright (c) 2015年 kimziv. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for xcomet.
FOUNDATION_EXPORT double xcometVersionNumber;

//! Project version string for xcomet.
FOUNDATION_EXPORT const unsigned char xcometVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <xcomet/PublicHeader.h>

#import <xcomet/XClient.h> 
#import <xcomet/XCMessage.h> 