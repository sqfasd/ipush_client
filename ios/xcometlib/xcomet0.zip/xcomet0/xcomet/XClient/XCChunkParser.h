//
//  XCChunkParser.h
//  xcomet
//
//  Created by kimziv on 15/5/7.
//  Copyright (c) 2015年 kimziv. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XCChunkParser : NSObject

@end
